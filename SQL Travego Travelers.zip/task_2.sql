use trivago;
select * from passenger;
select * from price;



# 1/ How many females and how many male passengers traveled a minimum distance of 600 KMs?
select gender,count(p_name) as total_count from passenger where distance >= 600 group by gender;

# 2/ Find the minimum ticket price of a Sleeper Bus. 
select min(price) from price;

# 3/ Select passenger names whose names start with character 'S' 
select p_name from passenger where p_name like "s%";

# 4/ Calculate price charged for each passenger displaying Passenger name, Boarding City, 
# Destination City, Bus_Type, Price in the output

select pa.P_name, pa.boarding_city, pa.destination_city, p.bus_type,pa.distance, pr.price
from passenger as pa left join price as pr
on pa.distance=pr.distance
and pa.bus_type=pr.bus_type
;


# 5/  What are the passenger name(s) and the ticket price for those who 
# traveled 1000 KMs Sitting in a bus?

select pa.p_name,pa.distance,pr.price 
from passenger as pa left join price as pr
on pa.distance=pr.distance
and pa.bus_type=pr.bus_type
where pa.distance=1000
;

# 6/ What will be the Sitting and Sleeper bus charge for 
# Pallavi to travel from Bangalore to Panaji?

select pa.p_name,pa.distance,pr.bus_type,pr.price 
from passenger as pa join price as pr
on pa.distance=pr.distance 
join price as p on 
pa.bus_type=p.bus_type
where pa.p_name='pallavi' limit 2
;


# 7/ List the distances from the "Passenger" table 
#which are unique (non-repeated distances) in descending order. 

select distinct(distance) from passenger order by distance desc;

# 8/ Display the passenger name and percentage of distance traveled by that 
# passenger from the total distance traveled by all passengers without using user variables 

select p_name,distance/(select sum(distance) as total_distance from passenger)*100 as total_distance_percentage
from passenger;


