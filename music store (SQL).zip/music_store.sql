use music;
select * from employee;

#Q.1
select employee_id,first_name,title,levels from employee order by levels desc;

#Q.2

select * from invoice;
select billing_country,count(invoice_id) as count1 from invoice
 group by billing_country order by count1 desc limit 1;
 
 
#Q.3
select * from invoice order by total desc limit 3;

#Q.4

select billing_city,sum(total) as total from invoice group by billing_city order by total desc limit 1 ;


#Q.5

select * from customer;
select * from invoice;

with my as(
select customer_id,sum(total) over(partition by customer_id) as total from invoice order by total desc limit 1
)
select m.customer_id,c.first_name,c.last_name,total from my as m join customer as c
on m.customer_id=c.customer_id;

select customer.customer_id,customer.first_name,customer.last_name,sum(invoice.total) as total
from customer join invoice
on customer.customer_id=invoice.customer_id
group by customer.customer_id,customer.first_name,customer.last_name
order by total desc limit 1;


#Q6
select * from genre;
select * from customer;
select * from invoice;
select * from track;

select distinct(customer.customer_id),email,last_name,first_name,genre.name 
from 
customer join invoice on customer.customer_id=invoice.customer_id
join invoice_line on invoice.invoice_id=invoice_line.invoice_id
join track on invoice_line.track_id=track.track_id
join genre on track.genre_id=genre.genre_id
where genre.name='Rock';

#Q7
select * from artist;
select * from album2;
select * from track;
select * from genre;
select * from album2 where artist_id=10;


select artist.artist_id,artist.name,count(artist.artist_id) as count
from track join album2 on album2.album_id=track.album_id
join artist on artist.artist_id=album2.artist_id
join genre on track.genre_id=genre.genre_id
where genre.name like "Rock"
group by artist.artist_id,artist.name
order by count desc limit 10;


#Q8
select name,milliseconds from track where milliseconds > (select avg(milliseconds) from track) order by milliseconds desc;

#Q9
select * from customer;
select * from invoice_line; 


select customer.customer_id,customer.first_name,artist.name as artist_name,sum(invoice_line.unit_price * invoice_line.quantity ) as spend
from customer join invoice on customer.customer_id=invoice.customer_id
join invoice_line on invoice.invoice_id=invoice_line.invoice_id
join track on invoice_line.track_id=track.track_id
join album2 on track.album_id=album2.album_id
join artist on album2.artist_id=artist.artist_id
group by customer.customer_id,customer.first_name,artist.name
order by spend desc;


#Q10
WITH popular_genre AS 
(
    SELECT COUNT(invoice_line.quantity) AS purchases, customer.country, genre.name, genre.genre_id, 
	ROW_NUMBER() OVER(PARTITION BY customer.country ORDER BY COUNT(invoice_line.quantity) DESC) AS RowNo 
    FROM invoice_line 
	JOIN invoice ON invoice.invoice_id = invoice_line.invoice_id
	JOIN customer ON customer.customer_id = invoice.customer_id
	JOIN track ON track.track_id = invoice_line.track_id
	JOIN genre ON genre.genre_id = track.genre_id
	GROUP BY 2,3,4
	ORDER BY 2 ASC, 1 DESC
)
SELECT * FROM popular_genre WHERE RowNo <= 1;


#Q11
WITH Customter_with_country AS (
		SELECT customer.customer_id,first_name,last_name,billing_country,SUM(total) AS total_spending,
	    ROW_NUMBER() OVER(PARTITION BY billing_country ORDER BY SUM(total) DESC) AS RowNo 
		FROM invoice
		JOIN customer ON customer.customer_id = invoice.customer_id
		GROUP BY 1,2,3,4
		ORDER BY 4 ASC,5 DESC)
SELECT * FROM Customter_with_country WHERE RowNo <= 1

